CREATE DATABASE ecommerce;
USE ecommerce;
-- DROP DATABASE ecommerce;
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    city VARCHAR(50),
    country VARCHAR(50),
    signup_date DATE
);
SELECT * FROM CUSTOMERS;

CREATE TABLE products (
    product_id INT PRIMARY KEY,
        product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    stock INT DEFAULT 0
);
SELECT * FROM products;

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    status VARCHAR(30),
    payment_method VARCHAR(30),

    FOREIGN KEY (customer_id)
    REFERENCES customers(customer_id)
);
SELECT * FROM orders;

CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (order_id)
    REFERENCES orders(order_id),

    FOREIGN KEY (product_id)
    REFERENCES products(product_id)
);
SELECT * FROM order_items;




